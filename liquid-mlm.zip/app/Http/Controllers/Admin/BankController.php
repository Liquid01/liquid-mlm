<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;

class BankController extends Controller
{
    //
}
