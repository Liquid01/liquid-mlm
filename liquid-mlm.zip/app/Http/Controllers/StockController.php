<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class StockController extends Controller
{
    //

    public function stockist_add_stock()
    {
        return redirect()->back();
    }
}
