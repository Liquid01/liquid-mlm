<?php

namespace App\Admin;

use Illuminate\Database\Eloquent\Model;

class Subscription extends Model
{
    //
}
