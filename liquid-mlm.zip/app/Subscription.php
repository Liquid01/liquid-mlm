<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Subscription extends Model
{
    protected $guarded = [];

//    protected $fillable = [
//        'by',
//        'type',
//        'product_id',
//        'denomination',
//        'message',
//        'reference',
//        'topup_currency',
//        'target',
//        'time',
//        'country',
//        'operator_name',
//        'customer_reference',
//        'msisdn',
//        'paid_amount',
//        'topup_amount',
//        'code',
//        'status',
//    ];
}
