<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class StageMatrix extends Model
{
    protected $fillable = ['username', 'stage'];
}
