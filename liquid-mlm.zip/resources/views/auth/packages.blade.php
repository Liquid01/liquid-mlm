@extends('layouts.register')

@section('content')

@endsection
