@extends('errors::minimal')

@section('title', __('Updates Installing'))
@section('code', '503')
@section('message', __('Maintenance - User Experience and Security Update Installing... Try again after few minutes'))
