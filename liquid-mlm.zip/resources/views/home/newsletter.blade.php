<section class="newsletter">
    <div class="container">
        <h3 class="text-center">Sign up for our newsletter to stay up to
            <br>date with tech news!</h3>

        <form action="#" class="newsletter-form" method="POST">
            <div class="row justify-content-between">
                <div class="col-md">
                    <input type="text" name="fname" placeholder="Your Name">
                </div>
                <div class="col-md">
                    <input type="text" name="email" placeholder="Your Email Address">
                </div>

                <div class="col-md-auto">
                    <a href="#" class="custom-btn btn-big grad-style-ef">SIGN UP FOR FREE</a>
                </div>
            </div>
            <!-- End of .row -->
        </form>
        <!-- End of .newsletter-form -->
    </div>
    <!-- End of .container -->
</section>
