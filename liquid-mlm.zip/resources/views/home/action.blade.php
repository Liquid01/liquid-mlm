<div class="wpo-cta-area">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="wpo-cta-text">
                    <h2>You Can Enjoy Health &amp; Wealth</h2>
                    <p>
                        Support someone into good health today; a product with all round protection, disinfection and correction
                        power can change the HEALTH and FINANCIAL status of the world around you.
                    </p>
                    <div class="btns">
                        <a href="{{route('compensation')}}" class="theme-btn">Learn More</a>
                        <a href="{{route('register')}}" class="theme-btn-s2">Join Us Now</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
