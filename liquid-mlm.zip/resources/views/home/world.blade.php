<div class="wpo-world-area">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="wpo-world-section">
                   <blockquote style="max-width:700px;">
                       <h4 style="font-size:20px">The World is Sweet.
                           SWEETER WHEN WE WORK TO HELP EACH OTHER GROW.
                       </h4>
                   </blockquote>



                    <a href="{{route('register')}}"><img src="{{asset('assets/images/team/1.png')}}" alt="">Join Us Now!</a>
                </div>
            </div>
        </div>
    </div>
</div>
