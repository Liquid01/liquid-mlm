<div class="wpo-counter-area">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="wpo-counter-grids">
                    <div class="grid">
                        <div>
                            <h2><span class="odometer" data-count="5120">00</span>+</h2>
                        </div>
                        <p>Members</p>
                    </div>
                    <div class="grid">
                        <div>
                            <h2><span class="odometer" data-count="350">00</span>+</h2>
                        </div>
                        <p>Testimonies</p>
                    </div>
                    <div class="grid">
                        <div>
                            <h2><span class="odometer" data-count="100000">00</span>+</h2>
                        </div>
                        <p>Stocks</p>
                    </div>
                    <div class="grid">
                        <div>
                            <h2><span class="odometer" data-count="80000">00</span>+ $</h2>
                        </div>
                        <p>Earned</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
