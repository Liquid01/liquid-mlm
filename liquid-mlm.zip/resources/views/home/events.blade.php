<section class="wpo-contact-form-map section-padding">
    <div class="container">
        <div class="row">
            <div class="col-12">

                <div class="wpo-contact-info">
                    <div class="row">
                        <div class="col-lg-4 col-md-6 col-sm-6 col-12">
                            <div class="info-item">
                                <h2>Worldwide Community</h2>
                                <div class="info-wrap">
                                    <div class="info-icon">
                                        <i class="ti-world"></i>
                                    </div>
                                    <div class="info-text">
                                        <span>WALNUTHEALTHCARE.COM</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-6 col-sm-6 col-12">
                            <div class="info-item">
                                <h2>Always in Touch</h2>
                                <div class="info-wrap">
                                    <div class="info-icon-2">
                                        <i class="fi flaticon-envelope"></i>
                                    </div>
                                    <div class="info-text">
                                        <span>+234 803 410 8410</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-6 col-sm-6 col-12">
                            <div class="info-item">
                                <h2>Excellent Support</h2>
                                <div class="info-wrap">
                                    <div class="info-icon-3">
                                        <i class="ti-headphone-alt"></i>
                                    </div>
                                    <div class="info-text">
                                        <span>info@walnuthealthcare.org</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div> <!-- end container -->
</section>
