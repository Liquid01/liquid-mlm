<div class="clients">
    <div class="container">
        <div class="row justify-content-center clients-wrapper">
            <div class="client">
                <img src="{{asset('assets2/images/clients/client-1.png')}}" alt="clients' logo">
            </div>
            <div class="client">
                <img src="{{asset('assets2/images/clients/client-2.png')}}" alt="clients' logo">
            </div>
            <div class="client">
                <img src="{{asset('assets2/images/clients/client-3.png')}}" alt="clients' logo">
            </div>
            <div class="client">
                <img src="{{asset('assets2/images/clients/client-4.png')}}" alt="clients' logo">
            </div>
            <div class="client">
                <img src="{{asset('assets2/images/clients/client-5.png')}}" alt="clients' logo">
            </div>
            <div class="client">
                <img src="{{asset('assets2/images/clients/client-6.png')}}" alt="clients' logo">
            </div>
            <div class="client">
                <img src="{{asset('assets2/images/clients/client-7.png')}}" alt="clients' logo">
            </div>
        </div>
    </div>
    <!-- End of .container -->
</div>