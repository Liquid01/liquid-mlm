

<div class="container" style="">

    <p style="float: right; font-size:15px!important; margin-right:3px; background:green; padding:5px 10px; margin-right:15px;">

        <a href="{{route('member_fund_wallet')}}" class="white-text"><i class="fa fa-wallet"></i>&nbsp;Fund Wallet</a>

    </p>

</div>
