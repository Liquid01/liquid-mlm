

<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="zxx">
<!--<![endif]-->

<head>

    <!-- Basic metas
    ======================================== -->
    <meta charset="utf-8">
    <meta name="author" content="Axilweb">
    <meta name="description" content="">
    <meta name="keywords" content="">

    <!-- Mobile specific metas
    ======================================== -->
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Page Title
    ======================================== -->
    <title>miracleseed Worldwide - a practical experience of success.</title>

    <!-- links for favicon
    ======================================== -->
    <link rel="apple-touch-icon" sizes="57x57" href="{{asset('assets2/images/logos/favicon.png')}}">
    <link rel="apple-touch-icon" sizes="60x60" href="{{asset('assets2/images/logos/favicon.png')}}">
    <link rel="apple-touch-icon" sizes="72x72" href="{{asset('assets2/images/logos/favicon.png')}}">
    <link rel="apple-touch-icon" sizes="76x76" href="{{asset('assets2/images/logos/favicon.png')}}">
    <link rel="apple-touch-icon" sizes="114x114" href="{{asset('assets2/images/logos/favicon.png')}}">
    <link rel="apple-touch-icon" sizes="120x120" href="{{asset('assets2/images/logos/favicon.png')}}">
    <link rel="apple-touch-icon" sizes="144x144" href="{{asset('assets2/images/logos/favicon.png')}}">
    <link rel="apple-touch-icon" sizes="152x152" href="{{asset('assets2/images/logos/favicon.png')}}">
    <link rel="apple-touch-icon" sizes="180x180" href="{{asset('assets2/images/logos/favicon.png')}}">
    <link rel="icon" type="image/png" sizes="192x192" href="{{asset('assets2/images/logos/favicon.png')}}">
    <link rel="icon" type="image/png" sizes="32x32" href="{{asset('assets2/images/logos/favicon.png')}}">
    <link rel="icon" type="image/png" sizes="96x96" href="{{asset('assets2/images/logos/favicon.png')}}">
    <link rel="icon" type="image/png" sizes="16x16" href="{{asset('assets2/images/logos/favicon.png')}}">
    <link rel="manifest" href="{{asset('assets2/favicon/manifest.json')}}">
    <meta name="msapplication-TileColor" content="#ffffff">
    <meta name="msapplication-TileImage" content="{{asset('assets2/favicon/ms-icon-144x144.png')}}">
    <meta name="theme-color" content="#ffffff">


    <!-- Icon fonts
    ======================================== -->
    <link rel="stylesheet" type="text/css" href="{{asset('assets2/css/miniline.css')}}">

    <!-- css links
    ======================================== -->
    <!-- Bootstrap link -->
    <link rel="stylesheet" type="text/css" href="{{asset('assets2/css/vendor/bootstrap.min.css')}}">

    <!-- Slick slider -->
    <link rel="stylesheet" type="text/css" href="{{asset('assets2/css/vendor/slick.css')}}">
    <link rel="stylesheet" type="text/css" href="{{asset('assets2/css/vendor/slick-theme.css')}}">

    <!-- Magnific popup -->
    <link rel="stylesheet" type="text/css" href="{{asset('assets2/css/vendor/magnific-popup.css')}}">

    <!-- Custom styles -->
    <link rel="stylesheet" type="text/css" href="{{asset('assets2/css/main.css')}}">

    <!-- Responsive styling -->
    <link rel="stylesheet" type="text/css" href="{{asset('assets2/css/responsive.css')}}">

</head>

<body class="test-class">

<!-- navbar starts
======================================= -->
<nav class="navbar navbar-expand-lg">
    <div class="container">
        <a class="navbar-brand" href="{{url('/')}}">
            <img src="{{asset('assets2/images/logo-150.png')}}" width="150px" alt="Brand Logo" class="img-fluid">
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false"
                aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
            <span class="custom-toggler-icon bar1"></span>
            <span class="custom-toggler-icon bar2"></span>
            <span class="custom-toggler-icon bar3"></span>
        </button>
        <!-- End of .navbar-toggler -->

        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ml-md-auto typo-color-c align-items-center">
                <li class="nav-item">
                    <a class="nav-link" href="pricing.html">Pricing</a>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-opener" href="#">
                        Courses
                    </a>
                    <div class="custom-dropdown-menu">
                        <a class="dropdown-item" href="website-design.html">Website Design</a>
                        <a class="dropdown-item" href="logo-and-branding.html">Logo &amp; Branding</a>
                        <a class="dropdown-item" href="mobile-app-development.html">Mobile App Development</a>
                        <a class="dropdown-item" href="search-engine-optimization.html">Cryptos &amp; NFTs</a>
                        <a class="dropdown-item" href="pay-per-click.html">Pay-Per-Click</a>
                        <a class="dropdown-item" href="social-media-marketing.html">Social Media Marketing</a>
                    </div>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-opener" href="#">
                        Services
                    </a>
                    <div class="custom-dropdown-menu">
                        <a class="dropdown-item" href="website-design.html">Website Design &amp; Development</a>
                        <a class="dropdown-item" href="logo-and-branding.html">Logo &amp; Branding</a>
                        <a class="dropdown-item" href="mobile-app-development.html">Mobile App Development</a>
                        <a class="dropdown-item" href="pay-per-click.html">Online/Digital Marketing</a>
                        <a class="dropdown-item" href="social-media-marketing.html">Business Automation</a>
                        <a class="dropdown-item" href="social-media-marketing.html">Training &amp; DEvelopment</a>
                    </div>
                </li>
                <li class="nav-item">
                    <a class="nav-link custom-btn btn-mid grad-style-cd" href="{{route('register')}}" data-bs-toggle="" data-bs-target="#get-a-quote-modal">Join</a>
                </li>
            </ul>
            <!-- End of .navbar-nav -->
        </div>
        <!-- End of .navbar-collapse -->
    </div>
    <!-- End of .container -->
</nav>
<!-- End of .navbar -->

@yield('content')

<!-- Footer starts
======================================= -->
<footer class="small-agency-footer  grey-bg">
    <svg class="bg-shape shape-footer-top reveal-from-left" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"
         width="779px" height="759px">
        <defs>
            <linearGradient id="PSgrad_05" x1="70.711%" x2="0%" y1="70.711%" y2="0%">
                <stop offset="0%" stop-color="rgb(237,247,255)" stop-opacity="1" />
                <stop offset="100%" stop-color="rgb(237,247,255)" stop-opacity="0" />
            </linearGradient>
        </defs>
        <path fill-rule="evenodd" fill="url(#PSgrad_05)" d="M111.652,578.171 L218.141,672.919 C355.910,795.500 568.207,784.561 692.320,648.484 C816.434,512.409 805.362,302.726 667.592,180.144 L561.104,85.396 C423.334,-37.184 211.037,-26.245 86.924,109.832 C-37.189,245.908 -26.118,455.590 111.652,578.171 Z"
        />
    </svg>

    <svg class="bg-shape shape-footer-bottom reveal-from-right" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"
         width="779px" height="759px">
        <defs>
            <linearGradient id="PSgrad_06" x1="70.711%" x2="0%" y1="70.711%" y2="0%">
                <stop offset="0%" stop-color="rgb(237,247,255)" stop-opacity="1" />
                <stop offset="100%" stop-color="rgb(237,247,255)" stop-opacity="0" />
            </linearGradient>
        </defs>
        <path fill-rule="evenodd" fill="url(#PSgrad_06)" d="M111.652,578.171 L218.141,672.919 C355.910,795.500 568.207,784.561 692.320,648.484 C816.434,512.409 805.362,302.726 667.592,180.144 L561.104,85.396 C423.334,-37.184 211.037,-26.245 86.924,109.832 C-37.189,245.908 -26.118,455.590 111.652,578.171 Z"
        />
    </svg>

    <div class="footer-nav-wrapper">
        <div class="container">
            <div class="row">
                <div class="col-md-3">
                    <a href="index.html" class="footer-logo">
                        <img src="{{asset('assets2/images/footer-logo.png')}}" alt="footer logo">
                    </a>

                    <ul class="social-icons">
                        <li>
                            <a href="http://www.behance.net/" target="_blank" rel="noopener">
                                <i class="fab fa-behance"></i>
                            </a>
                        </li>
                        <li>
                            <a href="http://twitter.com/" target="_blank" rel="noopener">
                                <i class="fab fa-twitter"></i>
                            </a>
                        </li>
                        <li>
                            <a href="http://plus.google.com/discover" target="_blank" rel="noopener">
                                <i class="fab fa-google-plus-g"></i>
                            </a>
                        </li>
                        <li>
                            <a href="http://dribbble.com/" target="_blank" rel="noopener">
                                <i class="fab fa-dribbble"></i>
                            </a>
                        </li>
                        <li>
                            <a href="http://youtube.com/" target="_blank" rel="noopener">
                                <i class="fab fa-youtube"></i>
                            </a>
                        </li>
                    </ul>
                    <!-- End of .social-icons -->
                </div>
                <!-- End of .col-md-3 -->

                <div class="col-md-3">
                    <nav class="footer-nav">
                        <h5>Services</h5>
                        <ul class="footer-menu">
                            <li>
                                <a href="logo-and-branding.html">Logo &amp; Branding</a>
                            </li>
                            <li>
                                <a href="pay-per-click.html">Pay-Per-Click</a>
                            </li>
                            <li>
                                <a href="website-design.html">Website Design</a>
                            </li>
                            <li>
                                <a href="mobile-app-development.html">Mobile App Design</a>
                            </li>
                            <li>
                                <a href="search-engine-optimization.html">Search Engine Optimization </a>
                            </li>
                            <li>
                                <a href="social-media-marketing.html">Social Media Marketing</a>
                            </li>
                        </ul>
                    </nav>
                </div>
                <!-- End of .col-md-3 -->

                <div class="col-md-3">
                    <nav class="footer-nav">
                        <h5>Support</h5>
                        <ul class="footer-menu">
                            <li>
                                <a href="contact.html">Contact</a>
                            </li>
                            <li>
                                <a href="privacy-policy.html">Privacy Policy</a>
                            </li>
                            <li>
                                <a href="terms-and-conditions.html">Terms &amp; Conditions</a>
                            </li>
                        </ul>
                    </nav>
                </div>
                <!-- End of .col-md-3 -->

                <div class="col-md-3">
                    <nav class="footer-nav">
                        <h5>Resources</h5>
                        <ul class="footer-menu">
                            <li>
                                <a href="portfolio.html">Portfolio</a>
                            </li>
                            <li>
                                <a href="case-studies.html">Case Studies</a>
                            </li>
                            <li>
                                <a href="about-us.html">About</a>
                            </li>
                            <li>
                                <a href="team.html">Team</a>
                            </li>
                            <li>
                                <a href="blog.html">Blog</a>
                            </li>
                        </ul>
                    </nav>
                </div>
                <!-- End of .col-md-3 -->
            </div>
            <!-- End of .row -->
        </div>
        <!-- End of .container -->
    </div>
    <!-- End of .footer-nav -->

    <div class="footer-bottom">
        <div class="container">
            <p class="text-center">&copy; 2021. All rights reserved by Your
                <a href="http://axilweb.com/" target="_blank">Company LLC</a>.</p>
        </div>
        <!-- End of .container -->
    </div>
    <!-- End of .footer-content -->
</footer>
<!-- End of footer -->

<!-- Featured-designs modal -->
<div class="modal fade featured-project-modal" id="featured-project-modal" tabindex="-1" role="dialog" aria-labelledby="featured-project-modal"
     aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <svg class="modal-bg" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="379px" height="369px">
                <defs>
                    <linearGradient id="PSgrad_012" x1="70.711%" x2="0%" y1="70.711%" y2="0%">
                        <stop offset="0%" stop-color="rgb(237,247,255)" stop-opacity="1" />
                        <stop offset="100%" stop-color="rgb(237,247,255)" stop-opacity="0" />
                    </linearGradient>

                </defs>
                <path fill-rule="evenodd" fill="url(#PSgrad_012)" d="M54.086,281.380 L105.962,327.505 C173.075,387.178 276.496,381.853 336.956,315.610 C397.418,249.367 392.025,147.292 324.911,87.619 L273.035,41.495 C205.921,-18.178 102.501,-12.853 42.040,53.390 C-18.422,119.633 -13.028,221.708 54.086,281.380 Z"
                />
            </svg>
            <!-- End of .modal-bg -->

            <svg class="featured-project-modal-bg" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="379px"
                 height="369px">
                <defs>
                    <linearGradient id="PSgrad_013" x1="70.711%" x2="0%" y1="70.711%" y2="0%">
                        <stop offset="0%" stop-color="rgb(237,247,255)" stop-opacity="1" />
                        <stop offset="100%" stop-color="rgb(237,247,255)" stop-opacity="0" />
                    </linearGradient>

                </defs>
                <path fill-rule="evenodd" fill="url(#PSgrad_013)" d="M54.086,281.380 L105.962,327.505 C173.075,387.178 276.496,381.853 336.956,315.610 C397.418,249.367 392.025,147.292 324.911,87.619 L273.035,41.495 C205.921,-18.178 102.501,-12.853 42.040,53.390 C-18.422,119.633 -13.028,221.708 54.086,281.380 Z"
                />
            </svg>
            <!-- End of .modal-bg -->

            <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
                <i class="ml-symtwo-24-multiply-cross-math"></i>
            </button>
            <!-- End of .close -->

            <div class="modal-body">
                <div class="row align-items-center">
                    <div class="col-lg-6">
                        <div id="featured-project-carousel" class="carousel slide featured-project-carousel" data-bs-ride="carousel">
                            <ol class="carousel-indicators">
                                <li data-bs-target="#featured-project-carousel" data-bs-slide-to="0" class="active"></li>
                                <li data-bs-target="#featured-project-carousel" data-bs-slide-to="1"></li>
                                <li data-bs-target="#featured-project-carousel" data-bs-slide-to="2"></li>
                            </ol>
                            <div class="carousel-inner">
                                <div class="carousel-item active">
                                    <img class="d-block w-100 img-fluid" src="{{asset('assets2/images/featured-projects/modal-img-1.jpg')}}" alt="First slide">
                                </div>
                                <div class="carousel-item">
                                    <img class="d-block w-100 img-fluid" src="{{asset('assets2/images/featured-projects/modal-img-1.jpg')}}" alt="Second slide">
                                </div>
                                <div class="carousel-item">
                                    <img class="d-block w-100 img-fluid" src="{{asset('assets2/images/featured-projects/modal-img-1.jpg')}}" alt="Third slide">
                                </div>
                            </div>
                            <a class="carousel-control-prev" href="#featured-project-carousel" role="button" data-bs-slide="prev">
                                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                                <span class="sr-only">Previous</span>
                            </a>
                            <a class="carousel-control-next" href="#featured-project-carousel" role="button" data-bs-slide="next">
                                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                                <span class="sr-only">Next</span>
                            </a>
                        </div>
                        <!-- End of .featured-project-carousel -->
                    </div>
                    <!-- End of .col-lg-6 -->

                    <div class="col-lg-6">
                        <div class="text-content">
                            <h3>
                                <span>Featured - Design</span> Second Language Website</h3>
                            <p>Donec mattis, augue condimentum varius vestibulum, magna lorem placerat ipsum, faucibus porta
                                libero ipsum ut lorem. Morbi sed purus interdum.</p>
                            <p>Ut porttitor odio eget mauris rutrum, a vehicula turpis llamcorper. Quisque iaculis leo non
                                eleifend pretium. Nunc ullamcorper scelerisque purus semper. </p>
                            <a href="#" class="custom-btn btn-big grad-style-ef">LAUNCH WEBSITE</a>
                        </div>
                        <!-- End of .text-content -->
                    </div>
                </div>
                <!-- End of .row -->
            </div>
            <!-- End of .modal-body -->
        </div>
        <!-- End of .modal-content -->
    </div>
    <!-- End of .modal-dialog -->
</div>
<!-- End of .modal -->

<!-- Get a quote Modal Starts -->
<div class="modal fade get-a-quote-modal" id="get-a-quote-modal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
                    <i class="ml-symtwo-24-multiply-cross-math"></i>
                </button>
                <!-- End of .close -->
            </div>
            <!-- End of .modal-header -->

            <div class="modal-body">
                <div class="contact-form-wrapper">
                    <div class="container">
                        <div class="row align-items-center">
                            <div class="col-lg-6">
                                <div class="contact-wrapper contact-page-form-wrapper">
                                    <div class="form-wrapper">
                                        <h3>Send Us a Message</h3>
                                        <form class="contact-form" method="post">
                                            <div class="row">
                                                <div class="col-md-12 col-lg-6">
                                                    <input type="text" name="fname" placeholder="Full Name">
                                                </div>

                                                <div class="col-md-12 col-lg-6">
                                                    <input type="email" name="email" placeholder="Email">
                                                </div>

                                                <div class="col-md-12 col-lg-6">
                                                    <input type="text" name="phone" placeholder="Phone">
                                                </div>

                                                <div class="col-md-12 col-lg-6">
                                                    <input type="text" name="website" placeholder="Website">
                                                </div>

                                                <div class="col-md-12">
                                                    <textarea name="message" placeholder="Message"></textarea>
                                                </div>
                                                <div class="btn-wrapper">
                                                    <button type="submit" class="custom-btn btn-big grad-style-ef">CONTACT US NOW</button>
                                                </div>
                                            </div>
                                            <!-- End of .row -->
                                        </form>
                                        <!-- End of .contact-form -->
                                    </div>
                                    <!-- End of .form-wrapper -->
                                </div>
                                <!-- End of .contact-form -->
                            </div>
                            <!-- End of .col-lg-7 -->

                            <div class="col-lg-6">
                                <div class="contact-info floating-contact-info">
                                    <h5>What’s Next?</h5>

                                    <div class="whats-next-wrapper">
                                        <p>
                                            <i class="ml-symone-68-arrow-left-right-up-down-increase-decrease"></i>An email and phone call from one of our representatives.</p>
                                        <p>
                                            <i class="ml-symone-68-arrow-left-right-up-down-increase-decrease"></i>A time &amp; cost estimation.</p>
                                        <p>
                                            <i class="ml-symone-68-arrow-left-right-up-down-increase-decrease"></i>An in-person meeting.</p>
                                    </div>
                                    <!-- End of .whats-next-wrapper -->

                                    <p class="address">
                                        Give us a call
                                        <a href="tel:7021231478">(702) 123-1478</a>
                                    </p>
                                    <!-- End of .address -->

                                    <p class="address">
                                        Send us an email
                                        <a href="mailto:info@company.com">info@company.com</a>
                                    </p>
                                    <!-- End of .address -->

                                    <div class="social-icons-wrapper">
                                        <p>Follow us on</p>
                                        <ul class="social-icons">
                                            <li>
                                                <a href="http://www.behance.net/" target="_blank" rel="noopener">
                                                    <i class="fab fa-behance"></i>
                                                </a>
                                            </li>
                                            <li>
                                                <a href="http://twitter.com/" target="_blank" rel="noopener">
                                                    <i class="fab fa-twitter"></i>
                                                </a>
                                            </li>
                                            <li>
                                                <a href="http://plus.google.com/discover" target="_blank" rel="noopener">
                                                    <i class="fab fa-google-plus-g"></i>
                                                </a>
                                            </li>
                                            <li>
                                                <a href="http://dribbble.com/" target="_blank" rel="noopener">
                                                    <i class="fab fa-dribbble"></i>
                                                </a>
                                            </li>
                                        </ul>
                                        <!-- End of .social-icons -->
                                    </div>
                                </div>
                                <!-- End of .contact-info -->
                            </div>
                            <!-- End of .col-lg-5 -->
                        </div>
                        <!-- End of .row -->
                    </div>
                    <!-- End of .container -->
                </div>
                <!-- End of .contact-form-wrapper -->
            </div>
            <!-- End of .modal-body -->
        </div>
        <!-- End of .modal-content -->
    </div>
    <!-- End of .modal-dialog -->
</div>
<!-- End of .get-a-quote-modal -->


<!-- Javascripts
======================================= -->
<!-- jQuery -->
<script src="{{asset('assets2/js/vendor/jquery-3.2.1.min.js')}}"></script>
<script src="{{asset('assets2/js/vendor/jquery-migrate.min.js')}}"></script>
<!-- Bootstrap js -->
<script src="{{asset('assets2/js/vendor/bootstrap.bundle.min.js')}}"></script>
<!-- font awesome -->
<script src="{{asset('assets2/js/vendor/fontawesome-all.min.js')}}"></script>
<!-- jQuery Easing Plugin -->
<script src="{{asset('assets2/js/vendor/easing-1.3.js')}}"></script>
<!-- jQuery progressbar plugin -->
<script src="{{asset('assets2/js/vendor/jquery.waypoints.min.js')}}"></script>
<script src="{{asset('assets2/js/vendor/jquery.counterup.min.js')}}"></script>
<!-- Bootstrap Progressbar -->
<script src="{{asset('assets2/js/vendor/bootstrap-progressbar.min.js')}}"></script>
<!-- ImagesLoaded js -->
<script src="{{asset('assets2/js/vendor/imagesloaded.pkgd.min.js')}}"></script>
<!-- Slick carousel js -->
<script src="{{asset('assets2/js/vendor/slick.min.js')}}"></script>
<!-- Magnific popup -->
<script src="{{asset('assets2/js/vendor/jquery.magnific-popup.min.js')}}"></script>
<script src="{{asset('assets2/js/vendor/isotope.pkgd.min.js')}}"></script>
<!-- scroll magic -->
<script src="{{asset('assets2/js/vendor/jquery.ScrollMagic.min.js')}}"></script>
<script src="{{asset('assets2/js/vendor/debug.addIndicators.min.js')}}"></script>
<script src="{{asset('assets2/js/vendor/jquery.TweenMax.min.js')}}"></script>
<script src="{{asset('assets2/js/vendor/animation.gsap.min.js')}}"></script>
<script src="{{asset('assets2/js/vendor/scrollReveal.js')}}"></script>
<!-- Custom js -->
<script src="{{asset('assets2/js/main.js')}}"></script>
</body>

</html>
