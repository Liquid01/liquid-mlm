<div class="wrap bg-white">

    <div class="container">

        <h1 class="color-success text-center mb-4">LATEST</h1>

        <div class="row color-dark">

            <div class="col-lg-3 col-md-4 col-xs-12 mix laptop apple" data-price="1999.99"

                 data-date="20160901">

                <div class="card wow zoomInUp" style="visibility: visible; animation-name: zoomInUp;">

                    <div class="card-block text-center">

                        <a href="javascript:void(0);">

                            <img src="{{asset('assets/img/latest/Walnut Healthcare --latest-1.png')}}" alt=""

                                 class="img-responsive center-block">

                        </a>

                        <h4 class="text-normal text-center">Walnut Healthcare - Seminars</h4>

                        <p>Earn free food items participating in our Seminars</p>

                        {{--<a href="javascript:void(0)"--}}

                           {{--class="btn btn-default btn-sm btn-sm btn-raised mt-2 no-mb">--}}

                            {{--<i class="zmdi zmdi-info-outline"></i> More</a>--}}

                    </div>

                </div>

            </div>

            <div class="col-lg-3 col-md-4 col-xs-12 mix laptop apple" data-price="1999.99"

                 data-date="20160901">

                <div class="card wow zoomInUp" style="visibility: visible; animation-name: zoomInUp;">

                    <div class="card-block text-center">

                        <a href="javascript:void(0);">

                            <img src="{{asset('assets/img/latest/Walnut Healthcare --latest-2.png')}}" alt=""

                                 class="img-responsive center-block">

                        </a>

                        <h4 class="text-normal text-center">Walnut Healthcare - Shirts</h4>

                        <p>Get into the spirit with our all-size fitted branded shirts</p>



                    </div>

                </div>

            </div>

            <div class="col-lg-3 col-md-4 col-xs-12 mix laptop apple" data-price="1999.99"

                 data-date="20160901">

                <div class="card wow zoomInUp" style="visibility: visible; animation-name: zoomInUp;">

                    <div class="card-block text-center">

                        <a href="javascript:void(0);">

                            <img src="{{asset('assets/img/latest/Walnut Healthcare --latest-3.png')}}" alt=""

                                 class="img-responsive center-block">

                        </a>

                        <h4 class="text-normal text-center">ZOOM FELLOWSHIP</h4>

                        <p> Learn, Share in the Walnut Healthcare - Members' Fellowship.</p>



                    </div>

                </div>

            </div>

            <div class="col-lg-3 col-md-4 col-xs-12 mix laptop apple" data-price="1999.99"

                 data-date="20160901">

                <div class="card wow zoomInUp" style="visibility: visible; animation-name: zoomInUp;">

                    <div class="card-block text-center">

                        <a href="javascript:void(0);">

                            <img src="{{asset('assets/img/latest/Walnut Healthcare --latest-4.png')}}" alt=""

                                 class="img-responsive center-block">

                        </a>

                        <h4 class="text-normal text-center">JOIN IN THE CHARITY</h4>

                        <p> Many People out there might not have as much, support.</p>



                    </div>

                </div>

            </div>

        </div>

        {{--<div class="btn btn-raised shopMore">More</div>--}}

        {{--<div class="text-center">--}}

            {{--<a href="{{route('guestshop')}}"--}}

               {{--class="btn btn-raised btn-dark animated fadeInUp icon-about animation-delay-10  btn-lg more ">--}}

                {{--<i class=" zmdi zmdi-info"></i>More Events--}}

                {{--<div class="ripple-container"></div>--}}

            {{--</a>--}}

        {{--</div>--}}



    </div>

    <!-- container -->

</div>

