<div class="row">

    <div class="carousel">
<h6>Walnut Healthcare - > <span class="active">Shop</span></h6>
{{--        <a class="carousel-item" href="#one!"><img src="{{asset('assets/img/products/productThumbImage/1565563372-headphone.png')}}" alt="Miracle Seed Ultima"></a>--}}

    </div>

</div>
