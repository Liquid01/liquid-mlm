@extends('layouts.admin')
@section('page_title')
    sYSTEM Settings
@endsection
@section('content')
    <div class="row">

        <div class="col s12">
            <div class="container">
                <!--card stats start-->

                <h1>SYSTEM SETTINGS</h1>
            </div>
        </div>
    </div>
@endsection
