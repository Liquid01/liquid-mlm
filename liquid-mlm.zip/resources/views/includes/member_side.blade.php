<div class="card">
    <div class="card-content">
        <div class="card-title"><h6>Upcoming Events</h6></div>
        <div class="row mt-5">
            <div class="col s12">
                <img class="responsive-img card-border z-depth-2 mt-2"
                     src="{{asset('backassets/images/gallery/post-3.png')}}"
                     alt="">
                <p><a href="#">First Quarter Skill Acquizition</a></p>
                <p>Our 1st Quarter Empowerment programmes on App Development, Online Marketing
                    & Paint Production Coming Soon <br>...Stay tuned.
                </p>
            </div>
        </div>
        <hr class="mt-5">
    </div>
</div>

