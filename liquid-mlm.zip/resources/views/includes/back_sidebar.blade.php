<!-- Today Highlight -->
<div class="col s12 m12 l3 hide-on-med-and-down">
    @include('includes.member_side')
</div>