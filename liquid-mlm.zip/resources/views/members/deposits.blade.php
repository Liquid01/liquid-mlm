@extends('layouts.members')
@section('page_title')
    My Deposits
@endsection
@section('content')
    <h3>My deposits</h3>
@endsection