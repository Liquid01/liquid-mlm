@extends('layouts.admin')



@section('content')

    <!-- BEGIN: Page Main-->

    {{--<div id=    "main">--}}

    <div class="row">

        <div class="content-wrapper-before black"></div>

        <div class="breadcrumbs-dark pb-0 pt-4" id="breadcrumbs-wrapper">

            <!-- Search for small screen-->

            <div class="container">

                <div class="row">

                    <div class="col s10 m6 l6">

                        <h5 class="breadcrumbs-title mt-0 mb-0">EDIT PRODUCT</h5>

                        <ol class="breadcrumbs mb-0">

                            <li class="breadcrumb-item"><a href="{{route('adminDashboard')}}">Dashboard</a>

                            </li>

                            <li class="breadcrumb-item"><a href="{{route('products')}}">Products</a>

                            </li>

                            <li class="breadcrumb-item active">create

                            </li>

                        </ol>

                    </div>



                </div>

                <div class="card center-align">

                    <div class="card-content" style="padding: 20px 5px;">

                        <a href="{{route('products')}}" data-target="modal1"

                           class=" modal-trigger waves-effect waves-light btn btn-small gradient-45deg-light-blue-cyan z-depth-4 mb-2">

                            All Product

                        </a>

                        {{--<a href="{{route('')}}" data-target="modal-withdraw" class="modal-trigger waves-effect waves-light btn btn-small gradient-45deg-red-pink z-depth-4 mb-2">--}}

                        {{--Shop--}}

                        {{--</a>--}}

                    </div>

                    @include('includes.flash')

                </div>

            </div>

        </div>





        <div class="col s12">

            <div class="container">

                <div class="section" id="user-profile">

                    <div class="row">

                        <div class="col s12 m8 l6">

                            <div class="row">

                                <div class="card user-card-negative-margin z-depth-0" id="feed">

                                    <div class="card-content card-border-gray">

                                        <div class="row">

                                            <div class="col s12">

                                                <div id="Form-advance" class="card card card-default scrollspy">

                                                    <div class="card-content">

                                                        <div class="row">

                                                            <div class="col m8 s8 l8">

                                                                <h4 class="card-title"

                                                                    style="display: inline!important;">Edit

                                                                    Product</h4>

                                                            </div>

                                                        </div>

                                                        <hr>

                                                        @include('includes.flash')

                                                        <form class="col s12" method="post"

                                                              action="{{route('update_product', $product)}}"

                                                              enctype="multipart/form-data">

                                                            @csrf

                                                            <div class="row">

                                                                <div class="input col s12">

                                                                    <select name="category_id" required

                                                                            class="{{ $errors->has('category_id') ? ' is-invalid' : '' }}"

                                                                            id="category_id">

                                                                        @foreach(\App\Category::all() as $key => $category)

                                                                            <option value="{{$category->id}}" {{$category->id == $product->category_id? 'selected':''}}>{{$category->name}}</option>

                                                                        @endforeach

                                                                    </select>

                                                                    <label>Category</label>

                                                                    @if ($errors->has('category_id'))

                                                                        <span class="invalid-feedback"

                                                                              role="alert">

                                                                                    <strong>{{ $errors->first('category_id') }} </strong>

                                                                                </span>

                                                                    @endif

                                                                </div>

                                                            </div>

                                                            <div class="row">

                                                                <div class="input-field col s12">

                                                                    <input id="name" name="name" required

                                                                           type="text"

                                                                           value="{{$product->name}}"

                                                                           class="{{ $errors->has('name') ? ' is-invalid' : '' }}">

                                                                    <label for="name">Product Name</label>

                                                                    @if ($errors->has('name'))

                                                                        <span class="invalid-feedback"

                                                                              role="alert">

                                                                                        <strong>{{ $errors->first('name') }} </strong>

                                                                                    </span>

                                                                    @endif

                                                                </div>

                                                            </div>



                                                            <div class="input-field col s12">

                                                                <input id="sales_price"

                                                                       class="{{ $errors->has('sales_price') ? ' is-invalid' : '' }}"

                                                                       name="sales_price"

                                                                       value="{{$product->sales_price}}"

                                                                       type="number">

                                                                <label for="sales_price">Price</label>

                                                                @if ($errors->has('sales_price'))

                                                                    <span class="invalid-feedback"

                                                                          role="alert">

                                                                                    <strong>{{ $errors->first('sales_price') }} </strong>

                                                                                </span>

                                                                @endif

                                                            </div>



                                                            <div class="row">

                                                                <div class="col s12 file-field input-field">

                                                                    <div class="col s6 m6">

                                                                        <div class="btn float-left">

                                                                            <span>Change</span>

                                                                            <input id="image" name="image"

                                                                                   class="file-path validate {{ $errors->has('image') ? ' is-invalid' : '' }}"

                                                                                    value=""

                                                                                   type="file">

                                                                        </div>

                                                                    </div>

                                                                    <div class="col s6 m6">

                                                                        <img src="{{asset('assets/img/products/productThumbImage/'.$product->image)}}" style="max-width:150px;" alt="" class="img img-responsive">



                                                                    </div>



                                                                @if ($errors->has('image'))

                                                                        <span class="invalid-feedback"

                                                                              role="alert">

                                                                                    <strong>{{ $errors->first('image') }} </strong>

                                                                                </span>

                                                                    @endif

                                                                </div>



                                                            </div>

                                                            <div class="row">

                                                                <div class="input-field col s12">

                                                                    <textarea id="description"

                                                                              name="description" required

                                                                              class="materialize-textarea {{ $errors->has('description') ? ' is-invalid' : '' }}">{{$product->description}}</textarea>

                                                                    <label for="description"

                                                                           class="active">Description</label>

                                                                    @if ($errors->has('description'))

                                                                        <span class="invalid-feedback"

                                                                              role="alert">

                                                                            <strong>{{ $errors->first('description') }} </strong>

                                                                        </span>

                                                                    @endif

                                                                </div>

                                                            </div>

                                                            <div class="row">

                                                                <div class="col s12 file-field input-field">

                                                                    <div class="file-path-wrapper">

                                                                        <button class="btn btn-lg save_product btn-block float-right">

                                                                            Update

                                                                        </button>

                                                                    </div>

                                                                </div>

                                                            </div>

                                                        </form>

                                                    </div>

                                                </div>

                                            </div>

                                        </div>

                                    </div>

                                </div>

                            </div>

                        </div>



                    </div>

                </div>

            </div>

        </div>

    </div>

    <!-- END: Page Main-->

@endsection
